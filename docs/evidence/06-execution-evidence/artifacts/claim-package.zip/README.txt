PREPARED - NOT SUBMITTED TO INSURER
This archive contains user-provided originals and a reviewed preparation summary.
AI explanations/translations are not insurer decisions or certified translations.
Check each insurer's current official channel and requested format.
